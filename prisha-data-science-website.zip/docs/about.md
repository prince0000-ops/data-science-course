# ℹ️ About Us

**Prisha Education**  
Data Science Training Institute

- 📍 Kolkata & Bihar (Hybrid: Classroom + Online)
- 🎯 Mission: Train jobless students and create employability
- 📞 Contact: +91-XXXXXXXXXX  
- ✉️ Email: info@prishaeducation.com  

---
*Affordable, job-ready data science training.*
