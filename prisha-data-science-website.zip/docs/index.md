# 📊 Prisha Education

**Empowering jobless students with affordable, industry-ready Data Science education.**  
We create employability in 100–300 sq. ft. classrooms and online.

## Why Prisha Education?
- Low-cost, high-value training.
- Stepwise learning: Beginner → Intermediate → Advanced → Job Prep.
- Hybrid model: classroom + online.
- Target: 1000+ students in 3 years, ₹50 lakh annual revenue.

---
🚀 *Turning small classrooms into big opportunities.*
