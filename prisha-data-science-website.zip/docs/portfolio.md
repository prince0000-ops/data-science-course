# 🌐 Portfolio Showcase

Every student gets a **personal portfolio site** powered by Streamlit & GitHub Pages.

- Run `python create_portfolio.py` to generate project index.
- Launch `streamlit run streamlit_app.py` to view projects.
- Optionally deploy via **GitHub Pages** with MkDocs.

Employers can browse student work in one click.
