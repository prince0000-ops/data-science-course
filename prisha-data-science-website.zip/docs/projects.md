# 🧑‍💻 Student Projects

Students will complete **3+ industry-grade projects** to showcase in their portfolio.

Example templates included:
- **Classification Project**: Predict job readiness from student profiles.  
- **Time Series Project**: Forecast sales or demand.  
- **NLP Project**: Sentiment analysis or text classification.

Projects include:
- Dataset
- Notebook templates
- Step-by-step guidance
