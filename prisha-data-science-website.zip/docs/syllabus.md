# 📘 Course Syllabus

### Phase 1 – Foundation (Day 1–100)
- Python Basics, Statistics, Excel for Data  
- Data Cleaning & Visualization (Matplotlib, Seaborn)

### Phase 2 – Core Data Science (Day 101–300)
- Machine Learning Fundamentals (Regression, Classification, Clustering)  
- SQL + Real-World Projects

### Phase 3 – Advanced (Day 301–600)
- Deep Learning (TensorFlow, PyTorch)  
- NLP, Computer Vision  
- Big Data Tools (Hadoop, Spark basics)

### Phase 4 – Career Readiness (Day 601–1000)
- Resume Building & Portfolio Projects  
- Mock Interviews, Hackathons  
- Freelancing & Job Placement Support

### Phase 5 – Growth (Day 1000–100000)
- MLOps, AI Ethics, Cloud AI  
- Industry collaboration projects  
- GenAI, Data Engineering
